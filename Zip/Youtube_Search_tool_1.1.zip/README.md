## No more distractions from recommended content.

1. Open the Chrome browser.
2. Type chrome://extensions/ in the address bar and press Enter.
3. Turn on the "Developer mode" switch in the top right corner.
4. Click "Load unpacked" and select the folder you created.

![Screenshot from 2024-09-09 18-46-47](https://github.com/user-attachments/assets/7fdc980c-765e-4ecf-b91d-2981ac08911b)

the version 1.0 is the basic function.